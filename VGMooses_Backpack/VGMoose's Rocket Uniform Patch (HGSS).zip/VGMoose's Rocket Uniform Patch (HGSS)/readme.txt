========================================
VGMoose's Rocket Uniform Patch v.9
http://dft.ba/-vgmoosebp
========================================


Instructions
	
	1) Run either xDelta GUI or xdelta.exe depending on how hardcore you are
	2) Select .patch file (Rocket Uniform.patch for the uninformed)
	3) Select totally and completely legal HG/SS ROM that you own (.nds)
	4) Apply patch
	5) ???
	
Something something profit joke.

So, ugh, wow, I don't want to write a whole new description. Copypasta up in this.

Well, this is a little bit better. The advantages over the first one I did, besides being an actual downloadable patch, include a nice clean script interface, and also some fancy hexing footwork around some of the limitations of the uniform (i.e. inability to fly.) Unfortunately, as soon as I removed the inability, I found out why it was there in the first place– the Rocket Uniform is temporary and wares off when the character changes sprites.

I was pretty disappointed when I found this out, but the event is rather nice and clean and I had already put the effort into it so I’m sharing it anyway.

To perfect his hack, short of modifying every single revert to original sprites check if the Rocket Uniform is on, would probably require an item. That way if the uniform were removed it could be put back on instantly. Also using the phone could work. I don’t have HEX offsets for either of those... however... so...

Well, darn. Maybe later.

Well, here's the thingy I alluded to (and by alluded to, I do mean blatantly said was going to happen) yesterday. It was kind of a huge pain to make, and after it was all done I was disappointed.

Here's the story. Normally, with the Rocket Uniform on, a variable is enabled that obviously tells the game that you're wearing it. This is used for NPCs when they talk to you and say things like "YOU'RE A BAD PERSON." Another variable is written to that prevents Fly from being used. I first disabled the NPC one, and everything was fine. I was able to maneuver Goldenrod without a problem. When I disabled the Fly one, however, I found something interesting.

The Rocket uniform is just as temporary as any other form (ie. surfing sprites, flying sprites, bicycle). It will wear off when one of the others are used. Unfortunately, this means that you can't surf, use your bike, or fly or else the Rocket sprites will be overwritten. I mean, you can easily enable them by going back to your house.

When I brought this up yesterday, I thought this might happen, and I suggested making an item. I spent liek a bazillion hours searching for the offsets where the item scripts are but I totally failed. If only right? (I'm looking at you slowpoketail– your time has come...)

Another alternative (but also another thing I don't have the offsets too...) would have been through a phone call or the radio even. Although, I think item is the way to go.

TLDR: THIS CULD B BETTR, HALP

Also, of course, test out the patchy to make sure it 1) actually works and 2) well, just actually works, that's all.

Thanks bros. Also, a quick shout out to PikalaxALT. He suggested recording through desmume at laggerific speeds to play back at full speed. Although I didn't actually use his method in this very video (got a new Wine distro), it sounds extremely useful and utilizable in the future. THXBRO.