==================================================================
Pokémon Second Generation Hacking Tools Package v1
Compiled by VGMoose
Tools by other cool people (credited in their app)
==================================================================

For more information on how to perform basic operations with these
hacking tools, see the tutorial at my website:
	http://dft.ba/-vba
	http://tinyurl.com/vgvba
	http://vgmoose.rickyayoub.com/Tutorials/Entries/2010/9/14_Using_Visual_Boy_Advance.html

In case subtly is dead, ROMs can be located at the following websites:
	http://www.doperoms.com
	http://www.thepiratebay.org
	http://www.emuparadise.org

The following applications most likley aren't covered in any of the tutorials
below, however, the process may be similar for that apps that are covered,
so they may be worth checking out:
	http://dft.ba/-hacktutorials
	http://tinyurl.com/vghacktutorials
	http://vgmoose.rickyayoub.com/Tutorials/Tutorials.html

Here's a list of all of the programs included, with a brief description of their function:
	AGIXP - Graphical Editor, extract and edit
	GoldMap - Overworld map editor for Gold and Silver
	Goldtweak - Tweak the introduction movie of G/S
	GS Mart Editor - Edit marts in G/S
	GSC TM Editor - Edit TMS in GSC
	ItemEd GSC - Edit items in GSC
	MegaMap - Another overworld editor
	pgsev10 - Sprite editor
	poketext - Edit text in Gen II. Also functions for Gen I
	StartEd GSC - Edit starters in GSC
	TradeEd GSC - Edit in game trades in GSC
	Visual Boy Linker - Gameboy emulator with link cable properties

Remember, for anything else you can visit my website:
	http://dft.ba/-vgmoosebp
	http://vgmoose.rickyayoub.com

Or shoot me an email:
	vgmoose@rickyayoub.com
	
Also don't forget to visit my Youtube channel for more Pokémon Hacks!
	http://youtube.com/vgmoose
	
Thanks and cheers!

-VGMoose