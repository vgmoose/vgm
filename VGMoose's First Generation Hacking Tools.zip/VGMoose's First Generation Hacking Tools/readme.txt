==================================================================
Pokémon First Generation Hacking Tools Package v1
Compiled by VGMoose
Tools by other cool people (credited in their app)
==================================================================

For more information on how to perform basic operations with these
hacking tools, see the tutorial at my website:
	http://dft.ba/-vba
	http://tinyurl.com/vgvba
	http://vgmoose.rickyayoub.com/Tutorials/Entries/2010/9/14_Using_Visual_Boy_Advance.html

In case subtly is dead, ROMs can be located at the following websites:
	http://www.doperoms.com
	http://www.thepiratebay.org
	http://www.emuparadise.org

The following applications most likley aren't covered in any of the tutorials
below, however, the process may be similar for that apps that are covered,
so they may be worth checking out:
	http://dft.ba/-hacktutorials
	http://tinyurl.com/vghacktutorials
	http://vgmoose.rickyayoub.com/Tutorials/Tutorials.html

Here's a list of all of the programs included, with a brief description of their function:
	Attack Editor GB - Edit Attacks. Functions with all Gen I games.
	Poke Edit GB - Edit the stats of Pokémon. Fuctions with all Gen I.
	Pokemap RB - Edit the maps. Compatable fully with Red and Blue versions (USA). Limited support is available for other Gen I (see readme in folder)
	Pokemon GAE4E - Gym and Elite Four editor for all Gen I. Pretty straightforward.
	Pokemon Title Editor RB - Edit the Pokémon on the R/B title screen.
	PokeStarter GB - Change the starter Pokémon in all Gen I games.
	Poketext - Edit the text! Compatable with all Gen I and Gen II games.
	RBG Title Editor - Another title screen editor. Not for Yellow version.
	RBGYTMEditor - TM editor for all of Gen I.
	RBTitlescreenEditor - Yet another title screen editor for R/B
	RBY Mart Editor - Edit marts in all Gen I.
	RBYGtrade - Edit in game trades in all Gen I.
	Silent - Another mart editor. Only functions for R/B (USA).
	Yellow Starter Editor - Edit all Overworld sprites in Pokémon yellow.
	Visual Boy Linker - Gameboy emulator with link cable properties

Remember, for anything else you can visit my website:
	http://dft.ba/-vgmoosebp
	http://vgmoose.rickyayoub.com

Or shoot me an email:
	vgmoose@rickyayoub.com
	
Also don't forget to visit my Youtube channel for more Pokémon Hacks!
	http://youtube.com/vgmoose
	
Thanks and cheers!

-VGMoose