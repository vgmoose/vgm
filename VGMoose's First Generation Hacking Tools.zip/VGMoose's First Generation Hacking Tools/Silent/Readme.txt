Readme file

Thanks for using Silent (why I chose the name, I don't know)

This program/tool is for editing the Pokemon Red/Blue version's store items. Sorry I couldn't get in the Vending Machine in Celadon City, I couldn't find the offsets for it.

Q&A
	Q: My ROM is Pokemon Red/Blue, but it says it's not
	A: It checks the internal rom name, and it's also 	   case-sensitive. It works for "Pokemon Red", 	   "Pokemon Blue", "POKEMON RED", and "POKEMON 	   BLUE". If it is, just go into a Hex Editor and 	   change it. Almost all Gameboy internal rom names 	   are at 0x134.

	Q: I get an error saving when I'm doing nothing 	   	   wrong?
	A: You probably already have the file open in 	   	   something else, like another Hex Editor.

	Q: Can I insert more than the original amount of 	   	   items?
	A: Yes, but it's hard. You gotta find free space, 	  	   which is easy. Then I don't know the rest xD

	Q: What's Comdlg32.OCX?
	A: A component needed if you don't have the VB6 run 	   time files installed. Basically the file browser

	Q: Why does this Q & A suck?
	A: Cause I wrote it


If you have any questions, feel free to e-mail me at InfiniteSkater@hotmail.com unless you're gay. (Most likely I won't check it, or respond back cause I don't check my email unless I'm expecting something =D)