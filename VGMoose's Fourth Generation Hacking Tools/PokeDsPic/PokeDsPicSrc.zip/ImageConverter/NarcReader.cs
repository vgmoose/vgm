﻿using System;
using System.IO;

public class NarcReader
{
    public int Entrys;
    public FileEntry[] fe;
    public FileStream fs;
    private string m_sFileName;
    public long size;

    public NarcReader(string strFileName)
    {
        this.m_sFileName = strFileName;
        this.fs = new FileStream(strFileName, FileMode.Open, FileAccess.ReadWrite);
        BinaryReader reader = new BinaryReader(this.fs);
        byte[] buffer = new byte[0x10];
        reader.Read(buffer, 0, 0x10);
        this.size = BitConverter.ToUInt32(buffer, 8);
        int num = BitConverter.ToInt16(buffer, 12);
        this.fs.Seek((long) num, SeekOrigin.Begin);
        buffer = new byte[12];
        reader.Read(buffer, 0, 12);
        int num2 = BitConverter.ToInt32(buffer, 4);
        this.Entrys = BitConverter.ToInt32(buffer, 8);
        this.fe = new FileEntry[this.Entrys];
        for (int i = 0; i < this.Entrys; i++)
        {
            this.fe[i].Ofs = reader.ReadInt32();
            this.fe[i].Size = reader.ReadInt32() - this.fe[i].Ofs;
        }
        this.fs.Seek((long) (num + num2), SeekOrigin.Begin);
        buffer = new byte[0x10];
        reader.Read(buffer, 0, 0x10);
        int num3 = BitConverter.ToInt32(buffer, 4);
        num3 = ((num + num3) + num2) + 8;
        for (int j = 0; j < this.Entrys; j++)
        {
            this.fe[j].Ofs += num3;
        }
        this.fs.Close();
    }

    public void Close()
    {
        this.fs.Close();
    }

    public int OpenEntry(int id)
    {
        this.fs = new FileStream(this.m_sFileName, FileMode.Open, FileAccess.ReadWrite);
        this.fs.Seek((long) this.fe[id].Ofs, SeekOrigin.Begin);
        return 0;
    }
}

