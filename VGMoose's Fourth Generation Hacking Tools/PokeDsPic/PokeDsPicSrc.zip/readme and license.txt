PokeDSPic Source
---


This is based on an MSDN example (hence the name) so i guess this means the
there might be a license carried over from there 
for me think of it as a BSD license
No GPL this time

loading